#include <iostream>
#include <stdlib.h>
#include <string.h>

class variable{
	public:
		char area[4];
		int valor;
		variable *siguiente;
};

typedef variable *apu_variable;

class areas{
	public:
		apu_variable inicio, aux, tope;
		areas(){
			inicio = NULL;
			aux = NULL;
			tope = NULL;
		}
		void insertar_a(char *apu, int dato_ext);
		int buscar_a(char *apu);
		void eliminar_a();
};

void areas::insertar_a(char *apu, int dato_ext){
	
	if(inicio == NULL){
		inicio = new(variable);
		strcpy(inicio->area, apu);
		inicio->valor = dato_ext;
		inicio->siguiente = NULL;
		tope = inicio;
		
		//--------------------------------------------------------------------
		aux = inicio;
		
		while(aux != NULL){
			printf("              %d   %s                ", aux->valor, aux->area);
			aux = aux->siguiente;
		}
		
		//-----------------------------------------------------------------------
		
	}
	else{
		
		if(areas::buscar_a(apu) != 0){
			aux = new(variable);
			strcpy(aux->area, apu);
			aux->valor = dato_ext;
			aux->siguiente = NULL;
			tope->siguiente = aux;
			tope = aux;
		}
		else{
			
			aux = inicio;
			
			while(aux != NULL){
				
				if(strcmp(aux->area,apu) == 0){
					aux->valor = aux->valor + dato_ext;
					break;
				}
				else{
					aux = aux->siguiente;
				}
				
			}
			
			//--------------------------------------------------------------------
			aux = inicio;
		
			while(aux != NULL){
				printf("              %d   %s                ", aux->valor, aux->area);
				aux = aux->siguiente;
			}
			//--------------------------------------------------------------------
			
		}
		
	}
	
}

int areas::buscar_a(char *apu){
	
	int cont = 0;
	
	aux = inicio;
	
	while(aux != NULL){
		
		if(strcmp(aux->area,apu) == 0){ // Si es 0 , son iguales
			return 0;
		}
		else{
			cont++;
			aux = aux->siguiente;
		}
		
	}
	
	return cont;
	
}

void areas::eliminar_a(){
	
	while(inicio != NULL){
		aux = inicio;
		inicio = inicio->siguiente;
		delete(aux);
	}
	
}

int main(){
	
	system("color 1b");
	
	int opc,
		ng,
		mi,
		mg;
	char renglon[100],
		 *apu;
	FILE *archivo;
	areas lista_areas;
	
	archivo = fopen("Cuestionario1.csv", "r");
	
	if(archivo == NULL){
		printf("No se abrio el archivo: Cuestionario1.csv correctamente...\n");
	}
	else{
		
		while(fgets(renglon, 100, archivo)){
			
			apu = strtok(renglon, ",");
			
			printf("\n%s \n", apu);
			printf( "\t1. No Me Gusta\n"
					"\t2. Me es Indiferentes\n"
					"\t3. Me Gusta\n"
					"\tOpcion: ");
					
			apu = strtok(NULL, ",");
			ng = atoi(apu);
			apu = strtok(NULL, ",");
			mi = atoi(apu);
			apu = strtok(NULL, ",");
			mg = atoi(apu);
			apu = strtok(NULL, "\n");
			//falta para variable de que area es
			
			scanf("%d", &opc);
			
			switch(opc){
				
				case 1:
					lista_areas.insertar_a(apu, ng);
				break;
				
				
				case 2:
					lista_areas.insertar_a(apu, mi);
				break;
				
				
				case 3:
					lista_areas.insertar_a(apu, mg);
				break;
				
			}
			
		}
		
	}
	
	return 0;
}
