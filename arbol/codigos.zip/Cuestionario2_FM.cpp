#include <iostream>
#include <stdlib.h>
#include <string.h>

class variable2{
	public:
		int valor;
		char grupo[8];
		variable2 *siguiente;
};

typedef variable2 *apu_variable2;

class grupos{
	public:
		apu_variable2 inicio, aux, tope;
		grupos(){
			inicio = NULL;
			aux = NULL;
			tope = NULL;
		}
		void insertar_g(char *apu_g, int valor_ext);
		int buscar_g(char *apu_g);
		void eliminar_g();
};

void grupos::insertar_g(char *apu_g, int valor_ext){
	
	if(inicio == NULL){
		inicio = new(variable2);
		strcpy(inicio->grupo, apu_g);
		inicio->valor = valor_ext;
		inicio->siguiente = NULL;
		tope = inicio;
		
		
		//--------------------------------------------------------------------
						aux = inicio;
						
						while(aux != NULL){
							printf("              %d   %s                ", aux->valor, aux->grupo);
							aux = aux->siguiente;
						}
		//--------------------------------------------------------------------
			
	}
	else{
		
		if(grupos::buscar_g(apu_g) != 0){ // Si no existe el grupo
			aux = new(variable2);
			strcpy(aux->grupo, apu_g);
			aux->valor = valor_ext;
			aux->siguiente = NULL;
			tope->siguiente = aux;
			tope = aux;
			
			
			//--------------------------------------------------------------------
			
							aux = inicio;
						
						while(aux != NULL){
							printf("              %d   %s                ", aux->valor, aux->grupo);
							aux = aux->siguiente;
						}
			//--------------------------------------------------------------------
		}
		else{
			aux = inicio;
			
			while(aux != NULL){
				
				if(strcmp(aux->grupo,apu_g) == 0){
					aux->valor = aux->valor + valor_ext;
					break;
				}
				else{
					aux = aux->siguiente;
				}
				
			}			
			
			//--------------------------------------------------------------------
			
						aux = inicio;
					
					while(aux != NULL){
						printf("              %d   %s                ", aux->valor, aux->grupo);
						aux = aux->siguiente;
					}
			//--------------------------------------------------------------------
			
		}
		
	}
	
}

int grupos::buscar_g(char *apu_g){
	
	int cont = 0;
	
	aux = inicio;
	
	while(aux != NULL){
		
		if(strcmp(aux->grupo,apu_g) == 0){ // si es 0, entonces son iguales..
			return 0;
		}
		else{
			cont++;
			aux = aux->siguiente;
		}
		
	}
	
	return cont;
	
}

void grupos::eliminar_g(){
	
	while(inicio != NULL){
		aux = inicio;
		inicio = inicio->siguiente;
		delete(aux);
	}
	
}

int main(){
	
	system("color 1b");
	
	int opc,
		ng,
		mi,
		mg;
	char renglon[100],
		 *apu_g;
	FILE *archivo_g;
	grupos lista_grupos;
	
	archivo_g = fopen("Cuestionario2_FM.csv", "r");
	
	if(archivo_g == NULL){
		printf("No se abrio el archivo: Cuestionario2_FM.csv correctamente...\n");
	}
	else{
		
		while(fgets(renglon,100,archivo_g)){
			
			apu_g = strtok(renglon,",");
			
			printf("\n%s \n", apu_g);
			printf( "\t1. No Me Gusta\n"
					"\t2. Me es Indiferentes\n"
					"\t3. Me Gusta\n"
					"\tOpcion: ");
			
			apu_g = strtok(NULL, ",");
			ng = atoi(apu_g);
			apu_g = strtok(NULL, ",");
			mi = atoi(apu_g);
			apu_g = strtok(NULL, ",");
			mg = atoi(apu_g);
			apu_g = strtok(NULL, "\n");
			
			scanf("%d", &opc);
			
			switch(opc){
				
				case 1:
					lista_grupos.insertar_g(apu_g, ng);
				break;
				
				
				case 2:
					lista_grupos.insertar_g(apu_g, mi);
				break;
				
				
				case 3:
					lista_grupos.insertar_g(apu_g, mg);
				break;
				
			}
			
		}
		
	}
	
}
